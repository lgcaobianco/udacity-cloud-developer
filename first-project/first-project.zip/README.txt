# First Project Udacity

## Important information
- [bucket endpoint](http://udacity-gucaobianco-project-1.s3-website-us-east-1.amazonaws.com/#/home)
- [cloudfront url](https://d29qr9q4j781ta.cloudfront.net/#/home)

Hey guys!

I've included a .pdf in a more friendly way to read the report from this assignment. As the assignment made it clead we had to include a readme.txt, I've included both, though I believe reading the pdf is easier than reading this file.

First of all, I have to provide an important disclaimer: instead of using the starter code, I've built my own website in Angular and used it to fulfill requirements for the current project.

My main language is PT-BR, and you may notice from the prints provided of my website that the text is in portuguese.

I hope this isn't an issue.

I've provided print screens for all topics mentioned in https://review.udacity.com/#!/rubrics/2573/view.

Best regards,

Luiz Gustavo Caobianco
